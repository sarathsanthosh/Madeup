import React, { Component, useState } from "react";
import "./account.css";
import "../../fonts/jost.css";
import profile from "../../images/profile.png";
import Form from "./Form";
import Orders from "./Orders";
import { Chevright , Chevdown, Chevup } from "../Icons/Index";
import Carousel from '../Carousel/Carousel'

class Account extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [
        { title: "My Profile", subtext: "Notification Passwords" },
        { title: "My orders", subtext: "You have 12 notifications" },
        { title: "Shipping addresses", subtext: "3 dresses" },
      ],
      target: "My Profile",
    };
  }
  handleClick(value) {
    this.setState({
      target: value,
    });
  }
  render() {
    return (
      <div className="profile">
        <nav>
          <div className="profile-card">
            <div>
              <img src={profile} />
            </div>
            <div>
              <h5>Grishk</h5>
              <p>griskim@gmail.com</p>
            </div>
            <Carousel/>
          </div>
          {this.state.data.map((card, i) => (
            <Card
              val={{ handleClick: this.handleClick.bind(this, card.title) }}
              key={i}
              title={card.title}
              subtext={card.subtext}
            />
          ))}
        </nav>
        <article className="form-order">
          {this.state.target === "My Profile" && <Form />}
          {this.state.target === "My orders" && <Orders />}
        </article>
      </div>
    );
  }
}
const Card = ({ val, title, subtext }) => {
  const [target, setTarget] = useState();
  const [open, setOpen] = useState(true);
  const [chev, setChev] = useState(true);

  const handleAddValue = () => {
    const newValue = title;
    setTarget(newValue);
    
  };
  const chevToggle = () =>{
    setOpen(!open);
    setChev(!chev);
  }
  
  return (
    <div>
      <div onClick={val.handleClick} value={title} className="card">
        <div className="card-container">
          <h4>
            <b>{title}</b>
          </h4>
          <p>{subtext}</p>
        </div>
        <div onClick={chevToggle} className="chevRight">
          <Chevright />
        </div>
      </div>
      <div onClick={handleAddValue} className="account-responsive">
        <div className="card-container">
          <h4>
            <b>{title}</b>
          </h4>
          <p>{subtext}</p>
        </div>
        <div  onClick={chevToggle} className="chevRight">
          {chev === true ?<Chevdown/>:<Chevup/>}
        </div>
        <div  className={`${!open ? "account-slidedown" : "account-slidehide"}`}>
          {target === "My Profile" && <Form />}
          {target === "My orders" && <Orders />}
        </div>
      </div>
    </div>
  );
};
export default Account;
