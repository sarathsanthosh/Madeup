import React, { Component } from "react";
import "./form.css";
import "../../fonts/jost.css";

class Form extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <form className="form-container">
        <div className="header">My Profile</div>
        <div className="nameContainer">
          <input type="text" placeholder="First Name" name="uname" required />
          <input type="text" placeholder="Last Name" name="uname" required />
        </div>
        <div className="mailContainer">
          <input type="email" placeholder="E mail" required></input>
        </div>
        <div className="numContainer">
          <input type="number" placeholder="Phone number" required></input>
        </div>
        <div className="passContainer">
          <input type="password" placeholder="Password" required></input>
        </div>
        <div className="confpassContainer">
          <input
            type="password"
            placeholder="Confirm Password"
            required
          ></input>
        </div>
        <div className="addAddress">
          <button className="addressButton">ADD NEW ADDRESS</button>
          <button className="addressResButton">Save Changes</button>
        </div>
      </form>
    );
  }
}

export default Form;
