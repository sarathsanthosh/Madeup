import React, { Component } from "react";
import "./article.css";
import "../../fonts/jost.css";
import headImg from "../../images/headerimg.png";
import section from "../../images/section-1.png";
import articletop from "../../images/sec-3.png";
import articlebutton from "../../images/sec-4.png";
import headerresImage from "../../images/carousel-2.png";
import { ChevLeft, Chevright } from "../Icons/Index";
import Carousel from '../Carousel/Carousel'

class Article extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: [
        { image: require("../../images/forme.png"), title: "For Me" },
        { image: require("../../images/joggers.png"), title: "Joggers" },
        { image: require("../../images/t-shirts.png"), title: "T-SHIRTS" },
        { image: require("../../images/shirts.png"), title: "Shirts" },
        { image: require("../../images/pants.png"), title: "Trousers" },
      ],
      currentImageIndex: 0,
    };
    this.nextSlide = this.nextSlide.bind(this);
    this.previousSlide = this.previousSlide.bind(this);
  }

  previousSlide() {
    const lastIndex = this.state.data.length - 1;
    const { currentImageIndex } = this.state;
    const shouldResetIndex = currentImageIndex === 0;
    const index = shouldResetIndex ? lastIndex : currentImageIndex - 1;
    this.setState({
      currentImageIndex: index,
    });
  }

  nextSlide() {
    const lastIndex = this.state.data.length - 1;
    const { currentImageIndex } = this.state;
    const shouldResetIndex = currentImageIndex === lastIndex;
    const index = shouldResetIndex ? 0 : currentImageIndex + 1;

    this.setState({
      currentImageIndex: index,
    });
  }

  render() {
    return (
      <div className="slider">
        <div className="nav-sel"><Carousel/></div>
        
        <div>
          <section className="headeroverlay">
            <p className="overlayPara main">
              Clothes that <span className="highlight">respire</span>{" "}
            </p>
            <p className="overlayPara main-down">
              For men who <span className="highlight">aspire</span>
            </p>
            <img className="headerImage" src={headImg}></img>
            <img className="headerresImage" src={headerresImage}></img>
          </section>
          <section className="mu-section">
            <p className="overlayPara left">
              <span className="highlight">Summer</span> is here and{" "}
            </p>
            <p className="overlayPara left-down">
              so is our <span className="highlight">collections</span>
            </p>
            <img className="section-top" src={section}></img>
            <div className="mu-article">
              <p className="overlayPara right">
                <span className="highlight">Wrinkle</span> free t-shirts
              </p>
              <p className="overlayPara right-down">
                <span className="highlight">Stain-free </span>denim shirts
              </p>
              <img src={articletop}></img>
              <img src={articlebutton}></img>
            </div>
          </section>
        </div>
        <div className="latestCollections">
          <h5>
            <span>LATEST COLLECTIONS</span>
          </h5>
        </div>
      </div>
    );
  }
}


export default Article;
