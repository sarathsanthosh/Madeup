import React from 'react';
import Account from '../../Components/Account/Account';

function pages() {

  return (
    <div className="App">
    <Account />
    </div>
  );
}

export default pages;